package com.telran.jdbcforum.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostAddDto {
    String content;
    String userName;
}
