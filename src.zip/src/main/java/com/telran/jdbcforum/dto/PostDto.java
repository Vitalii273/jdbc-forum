package com.telran.jdbcforum.dto;

import java.time.LocalDateTime;

public class PostDto {
    public int id;
    public String content;
    public LocalDateTime dateTime;
    public String userName;

}
